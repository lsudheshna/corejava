import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;


public class PersonPropertiesFile
{

	public static void main(String[] args)
	{
		FileReader fr=null;
		Properties props=null;
		
		try {
			
			fr=new FileReader("PersonProps.properties");
			props=new Properties();
			props.load(fr);
			
			String pname=props.getProperty("NAME");
			System.out.println("PERSON NAME:"+pname);
			
			String page=props.getProperty("AGE");
			System.out.println("PERSON AGE:"+page);
			
			String pcompany=props.getProperty("COMPANY");
			System.out.println("PERSON COMPANY:"+pcompany);
			
			String ploc=props.getProperty("LOCATION");
			System.out.println("PERSON LOCATION:"+ploc);
			
			String pstate=props.getProperty("STATE");
			System.out.println("PERSON STATE:"+pstate);
		} 
		catch (Exception e) 
		{
			
			e.printStackTrace();
		}
		
		

	}

}
