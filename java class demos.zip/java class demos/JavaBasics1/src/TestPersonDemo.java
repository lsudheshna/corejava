
public class TestPersonDemo {

	public static void main(String[] args)
	{
		Person p1=new Person("sudheshna","CBDS1557",10);
		Person p3=new Person("sudheshnachanna","DSFF1001",10);
		Person p2=new Person("sudheshna","CBDS1557",20);
		
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		
		if(p1.equals(p3))
		{
			System.out.println("same");
		
		}
		else
		{
			System.out.println("not same");
		}
		
		System.out.println("HashCode of p1:"+p1.hashCode());
		System.out.println("HashCode of p2:"+p2.hashCode());
		System.out.println("HashCode of p3:"+p3.hashCode());
	}
}
