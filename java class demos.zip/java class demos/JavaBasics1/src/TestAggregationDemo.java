import java.util.Scanner;

public class TestAggregationDemo 
{

	public static void main(String[] args)
	{	
		int n;
		int empId=0;
		String empName=null;
		float empSal=0.0f;
		String temp=null;
		Date empDOJ=null;
		int day=0;
		int month=0;
		int year=0;
		
		Scanner s=new Scanner(System.in);
		
		System.out.println("Enter number of employees");
		n=s.nextInt();
		Employee emps[]=new Employee[n];
		for(int i=0;i<n;i++)
		{
			
		System.out.println("Enter employee id");
		empId=s.nextInt();
		
		System.out.println("Enter employee Name");
		empName=s.next();
		
		System.out.println("Enter employee salary");
		empSal=s.nextFloat();
		
		System.out.println("Enter employee DOJ day");
		day=s.nextInt();
		System.out.println("Enter employee DOJ month");
		month=s.nextInt();
		System.out.println("Enter employee DOJ year");
		year=s.nextInt();
		empDOJ=new Date (day,month,year);
		

		emps[i]=new Employee(empId,empName,empSal,empDOJ);
		
		System.out.println("Employee details:"+emps[i].dispEmpInfo());
		}

	}

	


}





