
public class Employee
{
	private int empId;
	private String empName;
	private float empSal;
	private char empGender;
	
	public Employee()
	{
		empId=0;
		empName="UnKnown";
		empSal=0.0f;
		empGender=' ';
	}
	public Employee(int eid,String ename,float esal,char gen)
	{
		empId=eid;
		empName=ename;
		empSal=esal;
		empGender=gen;
	}
	public String dispEmployee()
	{
		return "Employee[empId="+empId+",empName="+empName+",empSal="+empSal+",empGender="+empGender+"]";
	}
	public float calcBasicSal()
	{
		return empSal;
	}
}

