import java.util.Scanner;

public class TestEmployee
{

	public static void main(String[] args)
	{	
		int n;
		int eid=0;
		String ename=null;
		float esal=0.0f;
		String temp=null;
		char gend=' ';
		
		
		Scanner s=new Scanner(System.in);
		
		System.out.println("Enter number of employees");
		n=s.nextInt();
		Employee emps[]=new Employee[n];
		for(int i=0;i<n;i++)
		{
			
		System.out.println("Enter employee id");
		eid=s.nextInt();
		
		System.out.println("Enter employee Name");
		ename=s.next();
		
		System.out.println("Enter employee salary");
		esal=s.nextFloat();
		
		System.out.println("Enter employee gender");
		temp=s.next();
		gend=temp.charAt(0);
		
		emps[i]=new Employee(eid,ename,esal,gend);
		System.out.println("Employee details:"+emps[i].dispEmployee());
		}

	}

}
