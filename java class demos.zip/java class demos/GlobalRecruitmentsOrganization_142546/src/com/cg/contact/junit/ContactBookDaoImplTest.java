package com.cg.contact.junit;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.contact.bean.EnquiryBean;
import com.cg.contact.dao.ContactBookDaoImpl;
import com.cg.contact.exception.ContactBookException;


public class ContactBookDaoImplTest 
{
	static EnquiryBean cbean=null;
	static EnquiryBean cbean1=null;
	static EnquiryBean cbean2=null;
	static ContactBookDaoImpl cDao=null;
	
	@BeforeClass
	public static void beforeClass()throws ContactBookException
	{
		cDao=new ContactBookDaoImpl();
		cbean=new EnquiryBean(cDao.generateEnquiryId(),"Ashwini","Raikar","8523827551","Java","Pune");
		cbean1=new EnquiryBean(cDao.generateEnquiryId(),"Amrutha","Shetty","7993263139","oracle","Mumbai");
		cbean2=new EnquiryBean(cDao.generateEnquiryId(),"Rohit","Agarwal","8008330877","Mainframes","Chennai");
	}
	@Test
	public void testAddEnquiry1()throws ContactBookException
	{
		Assert.assertEquals(1, cDao.addEnquiry(cbean));
	}
	@Test
	public void testAddEnquiry2()throws ContactBookException
	{
		Assert.assertEquals(1, cDao.addEnquiry(cbean1));
	}
	@Test
	public void testAddEnquiry3()throws ContactBookException
	{
		Assert.assertEquals(1, cDao.addEnquiry(cbean2));
	}
	@Test
	public void testGetEnquiryDetails()throws ContactBookException
	{
		Assert.assertNotNull(cDao.getEnquiryDetails1(cDao.generateEnquiryId()));
	}
}
