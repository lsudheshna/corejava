package com.cg.contact.util;

import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.*;

import com.cg.contact.exception.ContactBookException;


public class contactUtil 
{
	static String dbunm=null;
	static String dbpwd=null;
	static String url=null;

	public static Connection getCon()throws IOException,SQLException,ContactBookException
	{
		Connection con=null;
		Properties dbInfoprops=contactUtil.getProp();
		dbunm=dbInfoprops.getProperty("dbUser");
		dbpwd=dbInfoprops.getProperty("dbPwd");
		url=dbInfoprops.getProperty("dbURL");

		if(con==null)
		{
			
			con=DriverManager.getConnection(url,dbunm,dbpwd);
			
		}
		return con;
	}

	public static Properties getProp()throws IOException,ContactBookException
	{		
		FileReader fr=null;;
		Properties props=null;
		props=new Properties();
		fr = new FileReader("resources/contactInformation.properties");
		props.load(fr);
		return props;
	}

}
