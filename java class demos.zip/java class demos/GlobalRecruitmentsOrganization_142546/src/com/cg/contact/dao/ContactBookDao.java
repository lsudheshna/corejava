package com.cg.contact.dao;
import java.util.ArrayList;

import com.cg.contact.bean.EnquiryBean;
import com.cg.contact.exception.ContactBookException;

//USING INTERFACE FOR INSERING DETAILS,GENERATING ENQUIRYID,FETCHING DETAILS
public interface ContactBookDao
{
	
	public int addEnquiry(EnquiryBean enqry)throws ContactBookException;
	
	public EnquiryBean getEnquiryDetails(int EnquiryID)throws ContactBookException;

	int generateEnquiryId() throws ContactBookException;

	ArrayList<EnquiryBean> getEnquiryDetails1(int EnquiryID)
			throws ContactBookException;

}
