
public class TestStudentBeanDemo {

	public static void main(String[] args)
	{
		Student s1=new Student();
		s1.setRollNo(111);
		s1.setstuName("sudheshna");
		s1.setMark(100);
		
		System.out.println("Student Name:"+s1.getstuName());
		System.out.println("Student rollNo:"+s1.getRollNo());
		System.out.println("Student Mark:"+s1.getMark());
		System.out.println("***********************");
		
		Student s2=new Student();
		s2.setRollNo(222);
		s2.setstuName("channa");
		s2.setMark(80);
		
		System.out.println("Student Name:"+s2.getstuName());
		System.out.println("Student rollNo:"+s2.getRollNo());
		System.out.println("Student Mark:"+s2.getMark());
		System.out.println("***********************");
		
		Student s3=new Student();
		s3.setRollNo(333);
		s3.setstuName("Sai");
		s3.setMark(90);
		
		System.out.println("Student Name:"+s3.getstuName());
		System.out.println("Student rollNo:"+s3.getRollNo());
		System.out.println("Student Mark:"+s3.getMark());
		System.out.println("***********************");
	}

}
