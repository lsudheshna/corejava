
public class TestSwitchDemo {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		int day=Integer.parseInt(args[0]);
		switch(day)
		{
		case 6:
			System.out.println("Its saturday");
			break;
		case 7:
			System.out.println("Its sunday");
			break;
		default:
			System.out.println("Its week day");
				
		}

	}

}
