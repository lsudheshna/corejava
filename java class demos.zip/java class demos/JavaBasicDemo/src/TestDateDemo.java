
public class TestDateDemo {

	public static void main(String[] args)
	{
		 //Date channaDOJ,unknownPerson=null;
		 Date sudheshnaDOJ=new Date(13,12,2017);
		 Date channaDOJ=new Date(04,10,2017);
		 Date unknownPerson=new Date(1,1,2017);
		 System.out.println("Sudheshna DOJ:"+ sudheshnaDOJ.dispDate());
		 System.out.println("channa DOJ:"+ channaDOJ.dispDate());
		 System.out.println("unknownPerson DOJ:"+ unknownPerson.dispDate());
	}

}
