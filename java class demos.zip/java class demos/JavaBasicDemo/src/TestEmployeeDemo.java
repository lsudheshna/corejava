
public class TestEmployeeDemo {

	public static void main(String[] args)
	{
	
		Employee employee1=new Employee(101,"sudheshna",500f,'F');
		Employee employee2=new Employee(102,"channa",1500f,'F');
		Employee unknownPerson=new Employee(103,"unknownPerson",2500f,' ');
		System.out.println(employee1.dispEmployee());
		System.out.println(employee2.dispEmployee());
		System.out.println(unknownPerson.dispEmployee());	
		
	}

}
