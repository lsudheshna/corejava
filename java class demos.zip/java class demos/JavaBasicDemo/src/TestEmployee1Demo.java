
public class TestEmployee1Demo {

	public static void main(String[] args)
	{

	
		Employee1 employee1=new Employee1(101,"sudheshna",500f,'F');
		Employee1 employee2=new Employee1(102,"channa",1500f,'F');
		Employee1 unknownPerson=new Employee1(103,"unknownPerson",2500f,' ');
		System.out.println(employee1.dispEmployee1());
		System.out.println(employee2.dispEmployee1());
		System.out.println(unknownPerson.dispEmployee1());	
		
	}



}
