
public class TestArrayDemo {

	public static void main(String[] args)
	{
		int marks[]=new int[5];
		marks[0]=90;
		marks[1]=80;
		marks[2]=70;
		marks[3]=60;
		marks[4]=50;
		
		for(int i=0;i<marks.length;i++)
		{
			System.out.println("marks["+i+"]:"+marks[i]);
			
		}
		
		System.out.println("************");
	
		String cars[]={"BMW","Benz","Audi","Lamborghini","Fortuner"};
		
		for(int i=0;i<cars.length;i++)
		{
			System.out.println("cars["+i+"]:"+cars[i]);
			
		}
		
		System.out.println("************");
		
		int A[]=null;
		A=new int[3];
		A[0]=10;
		A[1]=9;
		A[2]=8;
		
		for(int i=0;i<A.length;i++)
		{
			System.out.println("A["+i+"]:"+A[i]);
			
		}
		
		System.out.println("************");
		
		
		
		int B[][]=new int[3][2];
		B[0][0]=90;
		B[0][1]=80;
		B[1][0]=70;
		B[1][1]=60;
		B[2][0]=50;
		B[2][1]=45;
				
		for(int i=0;i<B.length;i++)
		{
			for(int j=0;j<B[i].length;j++)
			{
			System.out.print(B[i][j]+" ");
			}
			System.out.println(" ");
		}
	
	}

}
