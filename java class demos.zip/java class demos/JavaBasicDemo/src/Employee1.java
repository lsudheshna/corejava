
public class Employee1
{
	private int empId;
	private String empName;
	private float empSal;
	private char empGender;
	
	public Employee1()
	{
		empId=0;
		empName="UnKnown";
		empSal=0.0f;
		empGender=' ';
		System.out.println("Empty constructor called");
	}
	public Employee1(int empId,String empName,float empSal,char empGender)
	{
		this();
		this.empId=empId;
		this.empName=empName;
		this.empSal=empSal;
		this.empGender=empGender;
	
	}
	public String dispEmployee1()
	{
		return "Employee[empId="+empId+",empName="+empName+",empSal="+empSal+",empGender="+empGender+"]";
	}
	public float calcBasicSal()
	{
		return empSal;
	}
}

