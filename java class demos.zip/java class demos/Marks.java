class Marks
{
public static void main(String args[])	
{ 
int marks=Integer.parseInt(args[0]);
if(marks<40)
System.out.println("Fail");
else if(marks>=40 && marks<60)
System.out.println("second class");
else if(marks>=60 && marks<75)
System.out.println("First class");
else if(marks>=75 && marks<=100)
System.out.println("Excellent");
else
System.out.println("invalid");
}
}