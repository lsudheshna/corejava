
public class Interfacedemo 
{
	public static void main(String args[])
	{
		Printable pp=new Box(8,9,10);
		System.out.println("Box Info:");
		pp.print();
		System.out.println("Volume of Box:"+((Box)pp).calcVol());
	}
}
