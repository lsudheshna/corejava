
public class WageEmployee1 extends Employee
{
	private int noOfHrs;
	private int ratePerHrs;
	
	public WageEmployee1()
	{
		super();
	}
	
	public WageEmployee1(int empId,String empName,float empSal,int noOfHrs, int ratePerHrs) 
	{
		super(empId,empName,empSal);
		this.noOfHrs = noOfHrs;
		this.ratePerHrs = ratePerHrs;
	}
	public float calcEmpBasicSal()//overriding
	{
		return super.calcEmpBasicSal()*ratePerHrs*noOfHrs*22;//22 is no of working days
	}
	public float calcEmpAnnualSal()//overriding
	{
		return calcEmpBasicSal()*12;
	}
	
}


