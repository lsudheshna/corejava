
public class TestInheritance
{
	public static void main(String[] args)
	{
		Employee sudheshna=new Employee(111,"sudheshna",20000.f);
		WageEmployee1 channa=new WageEmployee1(222,"channa",5000.0f,400,5);
		WageEmployee channa1=new WageEmployee(222,"channa",5000.0f,400,5);
		Employee channa2=new WageEmployee(233,"channa2",6000.0f,200,6);
		//channa2 is a wage employee and every wage employee is employee//
		
		
		System.out.println("Employee Info:"+sudheshna.dispEmpInfo());
		System.out.println("Employee Monthly salary:"+sudheshna.calcEmpBasicSal());
		System.out.println("Employee annual salary:"+sudheshna.calcEmpAnnualSal());
		
		System.out.println("Wage Employee Info:"+channa.dispEmpInfo());
		System.out.println("wage Employee Monthly salary:"+channa.calcEmpBasicSal());//calling overridden method
		System.out.println("Wage Employee annual salary:"+channa.calcEmpAnnualSal());
		
		System.out.println("Employee Info:"+channa2.dispEmpInfo());
		System.out.println("Employee Monthly salary:"+channa2.calcEmpBasicSal());
		System.out.println("Employee annual salary:"+channa2.calcEmpAnnualSal());

		System.out.println("Wage Employee Info:"+channa1.dispEmpInfo());
		System.out.println("wage Employee Monthly salary:"+channa1.calcWageEmpBasicSal());//Inheritance
		System.out.println("Wage Employee annual salary:"+channa1.calcWageEmpAnnualSal());
	
	
	
	
	}
}
