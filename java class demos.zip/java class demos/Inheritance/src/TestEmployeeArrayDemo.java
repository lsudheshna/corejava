import java.util.Scanner;
public class TestEmployeeArrayDemo 
{

	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter no of employees");
		int n=s.nextInt();
		Employee emps[]=new Employee[n];
		int eid=0;
		String eName=null;
		float eSal=0.0f;
		int ratePerHrs=0;
		int noOfHrs=0;
		
		for(int i=0;i<emps.length;i++)
		{	
			System.out.println("Enter emp id");
			eid=s.nextInt();
			System.out.println("Enter emp Name");
			eName=s.next();
			System.out.println("Enter emp salary");
			eSal=s.nextFloat();
			System.out.println("What type of employee you are?"+"1.Emp\t"+"2.WageEmp\t"+"3.Salesmgr");
			System.out.println("Enter choice");
			int choice=s.nextInt();
			switch(choice)
			{
			case 1:
				emps[i]=new Employee(eid,eName,eSal);
				
			break;
			case 2:
				System.out.println("Enter no of working hours");
				 noOfHrs=s.nextInt();
				System.out.println("Enter Rate Per Hour");
				ratePerHrs=s.nextInt();		
					emps[i]=new WageEmployee1(eid,eName,eSal,noOfHrs,ratePerHrs);
					break;
			default:
				System.out.println("Enter no of Sales");
				int sale=s.nextInt();
				System.out.println("Enter Commission");
				float commission=s.nextFloat();		
				emps[i]=new SalesManager(eid,eName,eSal,noOfHrs,ratePerHrs,sale,commission);
				break;
			
			}
		}
			for(int j=0;j<emps.length;j++)
			{
				if(emps[j] instanceof Employee)
				{		
					System.out.println(	"Employee Info"+emps[j].dispEmpInfo());
					System.out.println("Basic salary"+emps[j].calcEmpBasicSal());
					System.out.println("Anuual Salary"+emps[j].calcEmpAnnualSal());
				}
				else if(emps[j] instanceof WageEmployee1)
				{		
					System.out.println(	"Wage Employee Info"+emps[j].dispEmpInfo());
					System.out.println("Basic salary"+emps[j].calcEmpBasicSal());
					System.out.println("Anuual Salary"+emps[j].calcEmpAnnualSal());
				}
				else 
				{		
					System.out.println(	"Sales Manager Info"+emps[j].dispEmpInfo());
					System.out.println("Basic salary"+emps[j].calcEmpBasicSal());
					System.out.println("Anuual Salary"+emps[j].calcEmpAnnualSal());
				}
			}
			

	}

}
