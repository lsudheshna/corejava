
public class SalesManager extends WageEmployee1
{

	private float commission;
	private int sale;
	
	public SalesManager()
	{
		super();
	}
	
	public SalesManager(int empId,String empName,float empSal,int noOfHrs, int ratePerHrs,int sale,float commission) 
	{
		super(empId,empName,empSal,noOfHrs,ratePerHrs);
		this.sale=sale;
		this.commission=commission;
	}
	public float calcEmpBasicSal()//overriding
	{
		return super.calcEmpBasicSal()+(sale*commission);
	}
	public float calcEmpAnnualSal()//overriding
	{
		return calcEmpBasicSal()*12;
	}
}
