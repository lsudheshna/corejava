
public class TestInheritance1 {

	public static void main(String[] args) 
	{
		SalesManager s1=new SalesManager(111,"xxx",50000.0f,400,6,4,0.02f);

		System.out.println("Employee Info:"+s1.dispEmpInfo());
		System.out.println("Employee Monthly salary:"+s1.calcEmpBasicSal());
		System.out.println("Employee annual salary:"+s1.calcEmpAnnualSal());
	}

}
