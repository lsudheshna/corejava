
public class Tablet extends Medicine
{
	private String precaution="STORE IN COOL AND DRY PLACE";
	
	public Tablet(String medicineName, String companyName,int price,Date expiryDate)
		{
			super(medicineName,companyName,price,expiryDate);
			
		}
	
	public String MedicineInfo()
	{	
		return super.MedicineInfo()+"PRECAUTION:"+" "+precaution;
	}
	
}
