import java.util.Scanner;

public class TestMedicineDemo
{
		public static void main(String[] args)
		{
			Scanner s=new Scanner(System.in);
			System.out.println("Enter no of Medicines");
			int n=s.nextInt();
			Medicine meds[]=new Medicine[n];
			String medName=null;
			String comName=null;
			Date expDate=null;
			int price=0;
			int day=0;
			int month=0;
			int year=0;
			
			for(int i=0;i<meds.length;i++)
			{		
				
				System.out.println("Enter Medicine Name");
				medName=s.next();
				System.out.println("Enter Manufacturing Company Name");
				comName=s.next();
				System.out.println("Enter Price of a Medicine");
				price=s.nextInt();
				System.out.println("Enter expirydate day");
				day=s.nextInt();
				System.out.println("Enter expirydate month");
				month=s.nextInt();
				System.out.println("Enter expirydate year");
				year=s.nextInt();
				expDate=new Date (day,month,year);
				System.out.println("What type of Medicine you want to choose?"+"1.Tablet\t"+"2.Ointment\t"+"3.Syrup");
				System.out.println("Enter choice");
				int choice=s.nextInt();
				switch(choice)
				{
				case 1:
					meds[i]=new Tablet(medName,comName,price,expDate);	
					break;
				case 2:
					meds[i]=new Ointment(medName,comName,price,expDate);
					break;
				default:
					meds[i]=new Syrup(medName,comName,price,expDate);
					break;
				
				}
				
			}
				for(int j=0;j<meds.length;j++)
				{
					if(meds[j] instanceof Tablet)
					{		
						System.out.println(	"Medicine Info:" + meds[j].MedicineInfo());
						
					}
					else if(meds[j] instanceof Ointment)
					{		
						System.out.println(	"Medicine Info " + meds[j].MedicineInfo());
					}
					else 
					{		
						System.out.println(	"Medicine Info " + meds[j].MedicineInfo());
					}
				}	

	}

}
