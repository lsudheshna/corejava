
public class Ointment extends Medicine
{
	private String precaution="ONLY FOR EXTERNAL USE";
	
	public Ointment(String medicineName, String companyName,int price,Date expiryDate)
		{
			super(medicineName,companyName,price,expiryDate);
			
		}
	
	public String MedicineInfo()
	{	
		return super.MedicineInfo()+" "+"PRECAUTION:"+" "+precaution;
	}
}
