
public class Syrup extends Medicine
{
	private String precaution="SHAKE WELL BEFORE USE";
	
	public Syrup(String medicineName, String companyName,int price,Date expiryDate)
		{
			super(medicineName,companyName,price,expiryDate);
		
		}
	
	public String MedicineInfo()
	{	
		return super.MedicineInfo()+" "+"PRECAUTION:"+" "+precaution;
	}
}
