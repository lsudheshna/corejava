
public class WageEmployee extends Employee
{
	private int noOfHrs;
	private int ratePerHrs;
	
	public WageEmployee()
	{
		super();
	}
	
	public WageEmployee(int empId,String empName,float empSal,int noOfHrs, int ratePerHrs) 
	{
		super(empId,empName,empSal);
		this.noOfHrs = noOfHrs;
		this.ratePerHrs = ratePerHrs;
	}
	public float calcWageEmpBasicSal()
	{
		return super.calcEmpBasicSal()*ratePerHrs*noOfHrs*22;//22 is no of working days
	}
	public float calcWageEmpAnnualSal()
	{
		return calcWageEmpBasicSal()*12;
	}
	
}
