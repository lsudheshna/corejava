
public class Medicine 
{
	private String medicineName;
	private String companyName;
	Date expiryDate;
	private int price;
	
	public Medicine(String medicineName, String companyName,int price,
			Date expiryDate)
	{
		this.medicineName = medicineName;
		this.companyName = companyName;
		this.price = price;
		this.expiryDate=expiryDate;
	}
	
	public Medicine()
	{
		super();
		expiryDate=new Date();
	}
	
	public String MedicineInfo()
	{
		return "MEDICINE NAME:"+" "+medicineName+" "+"COMPANY NAME:"+" "+companyName+" "+"EXPIRY DATE:"+" " +expiryDate.dispDate()+" "+"PRICE:"+" " +price;
	}
}
