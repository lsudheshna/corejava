
public class ProductArray
{

	public static void main(String[] args) 
	{
		String product[]={"REVLON","LAKME","MAC","MAYBELLINE","MAC"};
		
		
		

	}

}
