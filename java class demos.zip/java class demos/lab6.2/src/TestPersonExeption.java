
public class TestPersonExeption 
{
	
	public static void main(String args[])
	{
		
           Person p1=new Person();
		try
		{
			p1.setAge(14.00f);

		}
		catch(PersonException ne)
		{
			System.out.println("A person should be a major to have an account");
			ne.printStackTrace();
		}
	}
}





