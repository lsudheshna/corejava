
public class PersonException extends Exception
{
	public PersonException(String msg)
	{
		super(msg);
	}
}
