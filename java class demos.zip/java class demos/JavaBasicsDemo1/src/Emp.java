
public class Emp 
{
	private int empId;
	private String empName;
	private float empSal;
	static int empCount;
	
	static
	{
		System.out.println("Emp static block:");
		empCount=5;
	}
	public int getEmpId()
	{
		return empId;
	}
	public String getEmpName()
	{
		return empName;
	}
	public float getEmpSal()
	{
		return empSal;
	}
	
	public Emp(int empId,String empName,float empSal)
	{
		this.empId=empId;
		this.empName=empName;
		this.empSal=empSal;
		empCount++;
	}
		
	public String dispEmp()
	{
		return "Employee[empId="+empId+",empName="+empName+",empSal="+empSal+"]";
	}
	public static void getCount()
	{
		System.out.println("Emp count is:"+empCount);
	}
	
	
	
	
}
