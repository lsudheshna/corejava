
public class TestStaticEmpDemo
{
	static
	{
		System.out.println("This is TestStaticempDemo static block");
	}
	public static void main(String args[])
	{
		Emp e1=new Emp(111,"sudheshna",1000.0f);
		Emp e2=new Emp(222,"channa",200.0f);
		System.out.println(e1.dispEmp());
		System.out.println(e2.dispEmp());
		Emp.getCount();
	
	}
	
}