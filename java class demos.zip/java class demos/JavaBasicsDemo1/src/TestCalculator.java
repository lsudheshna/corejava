class Calculator
{
	public void add(int a,int b)
	{
		System.out.println("addition of 2 int:"+(a+b));
	}
	public void add(int a,int b,int c)
	{
		System.out.println("addition of 3 int:"+(a+b+c));
	}
	public void add(byte a,byte b)
	{
		System.out.println("addition of 2 byte:"+(a+b));
	}
	public void add(float a,float b)
	{
		System.out.println("addition of 2 float:"+(a+b));
	}
	public void add(String a,String b)
	{
		System.out.println("Concatnation of 2 string:"+a+" "+b);
	}
	public void add(double a,double b)
	{
		System.out.println("addition of 2 double:"+(a+b));
	}
	public void add(Integer a,Integer b)//wrapper class ---int has wrapper class called Integer which is static
	{
		System.out.println("wrap of 2 int:"+(a+b));
	}

}
public class TestCalculator
{

	public static void main(String[] args) 
	{
		Calculator c=new Calculator();
		c.add(10, 20);
		c.add(10,20,30);
		c.add(10.00, 11.00);
		c.add(10.0F, 20.0F);
		c.add("sudheshna","channa");
		c.add((byte)10,(byte)5);
		Integer i1=new Integer(10);
		c.add(i1,new Integer(20));
		
	}

}
