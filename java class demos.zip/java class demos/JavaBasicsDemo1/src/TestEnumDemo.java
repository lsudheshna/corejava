enum Seasons
{
	SUMMER,RAINY,WINTER;
}
public class TestEnumDemo
{

	public static void main(String[] args)
	{
		for (Seasons s : Seasons.values())  
			System.out.println(s); 
		
	
	}

}
