import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;
interface MaxFinder
{
	public int max(int num1,int num2);
}

public class TestlambdaExpr 
{
	public static void main(String[] args)
	{
		Consumer<String> consumer=
				(String str)->
		System.out.println(str);
				consumer.accept("welcome");
		Supplier<String> sup=
				()->"Happy new Year";
				System.out.println(sup.get());
				
		BiFunction<Integer,Integer,Integer> biFunction=(x,y)->x>y?x:y;
		System.out.println("Greatest number is:"+biFunction.apply(90,100));			
	
		Predicate<Integer> predicate=(num)->num%2==0;
		System.out.println("Is 4 Even No?"+predicate.test(4));
		System.out.println("Is 3 Even No?"+predicate.test(3));
		
	}

}
