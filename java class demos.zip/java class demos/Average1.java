class Average1
{
	public static void main(String args[])	
	{ 
		float sum=0;
		float avg;
	
		for(int i=0;i<10;i++)
		{
			sum+=Integer.parseInt(args[i]);
			
			
		}
		avg=sum/10;
		System.out.println(avg);
		System.out.println(sum);
	}
}