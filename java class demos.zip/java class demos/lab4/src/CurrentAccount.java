
public class CurrentAccount extends Account
{
	private final int overDraftLimit=80000;

	public CurrentAccount(long accNum, double balance, Person accHolder) 
	{
		super(accNum, balance, accHolder);
		
	}
	
	public void withdraw(double amt)
	{
		if(overDraftLimit>amt)
		{
		amt=overDraftLimit-amt;
		System.out.println("Total Amount is:"+amt);
		}
		else
		{
			System.out.println("Limit has exceeded");
		}
	}
	public String dispAccountDetails() 
	{
		return super.dispAccountDetails();
	}
}


