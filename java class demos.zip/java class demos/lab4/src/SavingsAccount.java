
public class SavingsAccount extends Account 
{
	private final int minBalance=3000;

	public SavingsAccount(long accNum, double balance, Person accHolder) 
	{
		super(accNum, balance, accHolder);
		
	}
	
	public void withdraw(double amt)
	{
		if(minBalance>amt)
		{
		amt=getBalance()-amt;
		System.out.println("Total Amount is:"+amt);
		}
		else
		{
			System.out.println("No Balance in your Account");
		}
	}
	public String dispAccountDetails() 
	{
		return super.dispAccountDetails();
	}
}
