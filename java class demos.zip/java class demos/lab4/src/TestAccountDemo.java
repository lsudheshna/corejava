
public class TestAccountDemo {

	public static void main(String[] args)
	{
		Person smith=new Person("smith",30);
		Person Kathy=new Person("Kathy",32);
		
		Account acc1=new Account(1212301l,2000.00,smith);
		Account acc2=new Account(1431211l,3000.00,Kathy);

		acc1.setBalance(2000.00);
		acc2.setBalance(3000.00);
		acc1.deposit(2000.00);
		acc2.withdraw(4000.00);
		
		System.out.println("ACCOUNT DETAILS: "+acc1.dispAccountDetails());
		System.out.println("ACCOUNT DETAILS: "+acc2.dispAccountDetails());
		System.out.println();
		
		SavingsAccount s1=new SavingsAccount(1212301l,2000.00,smith);
		SavingsAccount s2=new SavingsAccount(1431211l,3000.00,Kathy);
		
		s1.withdraw(2000.00);
		s2.withdraw(4000.00);
		
		System.out.println("UPDATED SAVINGS ACCOUNT DETAILS: "+s1.dispAccountDetails());
		System.out.println("UPDATED SAVINGS ACCOUNT DETAILS: "+s2.dispAccountDetails());
		System.out.println();
		
		CurrentAccount c1=new CurrentAccount(1212301l,2000.00,smith);
		CurrentAccount c2=new CurrentAccount(1431211l,3000.00,Kathy);
		
		c1.withdraw(90000.00);
		c2.withdraw(4000.00);
		
		System.out.println("UPDATED CURRENT ACCOUNT DETAILS: "+s1.dispAccountDetails());
		System.out.println("UPDATED CURRENT ACCOUNT DETAILS: "+s2.dispAccountDetails());
		
		
	}

}
