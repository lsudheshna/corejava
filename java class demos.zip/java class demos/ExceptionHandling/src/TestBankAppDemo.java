import java.util.Scanner;


public class TestBankAppDemo {

	public static void main(String[] args)//throws LowBalanceException
	{
		Scanner s=new Scanner(System.in);
	
		int currentBalance=60000;
		System.out.println("Enter the withdraw Amount");
		int withdrawAmt=s.nextInt();
		if(withdrawAmt<currentBalance)
		{
			System.out.println("U can withdraw Amount");
		}
		else
		{
			try 
			{
				throw new LowBalanceException("plz check ur Balance in ur account");
			} 
			catch (LowBalanceException e)
			{
				System.out.println("Insufficient Balance in ur account");
				e.printStackTrace();
			}
			
			//throw new LowBalanceException("plz check ur Balance in ur account");
			
		}
	}

}
