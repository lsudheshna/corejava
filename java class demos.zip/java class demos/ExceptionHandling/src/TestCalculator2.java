import java.time.LocalDate;
import java.util.Scanner;

class Calculator
{
	int num1,num2;
	//int nums[]=new int[2];
	public Calculator()
	{
		
	}
	public Calculator(int num1,int num2)
	{
		this.num1=num1;
		this.num2=num2;
		/*nums[0]=num1;
		nums[1]=num2;*/
	}
	public float doDivision()
	{
		float result=0.0f;
		try
		{
			//System.out.println("3rd Location of "+"Nums"+" is:"+nums[2]);
			result=num1/num2;
		}
		catch(ArithmeticException ae)
		{
			System.out.println("please check the divisor"+ae.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		/*finally
		{
			System.out.println("This block is always executed whether exception occurs or not");
		}*/
		return (int)result;
	}
}
public class TestCalculator2
{
	public static void main(String args[])
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter num1:");
		int num1=s.nextInt();
		System.out.println("Enter num2:");
		int num2=s.nextInt();
		Calculator cc=new Calculator(num1,num2);
		System.out.println("Division of 2 Number Is:"+cc.doDivision());
		LocalDate today=null;
		System.out.println("Today Is:"+LocalDate.now());
	}
}







