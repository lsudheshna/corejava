import com.cg.bat.Batch;
import com.cg.stu.Student;
public class TestStudentDemo {

	public static void main(String[] args)
	{
		Batch javaBatch=new Batch("JEE_propel_001","8.30 TO 6.00","Anjulatha Tembhare");
		
		Batch vnvBatch=new Batch("VNV_PT_002","9.30 TO 6.00","Shilpa Bhosale");
		
		Batch oraBatch=new Batch("oraApp_ABridge_003","8.30 TO 5.00","Sachin Naredkar");
	
		Student student1=new Student(111,"Ronak",90,javaBatch);
		
		Student student2=new Student(222,"Sudheshna",95,javaBatch);
		
		Student student3=new Student(333,"Gowtham",50,vnvBatch);
		
		Student student4=new Student(444,"Kanna",80,oraBatch);
	
		System.out.println(student1.dispStuInfo());
		System.out.println(student2.dispStuInfo());
		System.out.println(student3.dispStuInfo());
		System.out.println(student4.dispStuInfo());
	
	}

}
