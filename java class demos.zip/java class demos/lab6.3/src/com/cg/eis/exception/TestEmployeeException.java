package com.cg.eis.exception;

import java.util.Scanner;

public class TestEmployeeException 
{

	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter salary of an employee");
		float sal=s.nextFloat();
		if(sal>3000)
		{
			System.out.println("An employee should have a basic salary of 3000");
		}
		else
		{
			try
			{
				throw new EmployeeException("An employee basic salary is 3000");
			}
			catch(EmployeeException e)
			{
				System.out.println("An employee should have a basic salary of 3000");
				e.printStackTrace();
			}
		}

	}

}
