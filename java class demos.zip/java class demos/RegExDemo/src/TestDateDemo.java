import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class TestDateDemo 
{
	public static void main(String[] args)
	{
		LocalDate today1=LocalDate.now();
		System.out.println(today1);
		
		LocalDate myDOJ=LocalDate.of(2010,04,03);
		System.out.println("my DOJ:"+myDOJ);
		// to convert other formats to default format--->25-dec-2017 to 2017-12-25
		String myDOJ1="25-Dec-2017";
		
		DateTimeFormatter myformat=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		LocalDate myDOJ2=LocalDate.parse(myDOJ1,myformat);
		System.out.println(myDOJ2);
		
		//to string --->2017-12-25 to 2017-dec-25
		DateTimeFormatter myforamt1=DateTimeFormatter.ofPattern("YYYY-MMM-dd");
		String urDOJ=myDOJ2.format(myforamt1);
		System.out.println(urDOJ);
		
		
		//Difference of 2 dates
		
		Period period=Period.between(myDOJ,today1);
		int yrs=period.getYears();
		int mnt=period.getMonths();
		int dys=period.getDays();
		
		System.out.println(yrs+" "+mnt+" " +dys);
	}

}
