
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegExDemo
{
	public static void main(String args[])
	{
		String inputStr="Test String";
		String pattern="Test String";
		boolean patternMatched=Pattern.matches(pattern,inputStr);
		System.out.println(patternMatched);
		System.out.println("*****************");
	
		String input="Shop,Mop,Hopping,Chopping";
		Pattern pattern1=Pattern.compile("hop");
		Matcher matcher=pattern1.matcher(input);
		
		while(matcher.find())
		{
			System.out.println(matcher.group()+":"+matcher.start()+":"+matcher.end());
		}
		
		
		Scanner s=new Scanner(System.in);
		System.out.println("Enter ur mobile No");
		String mobile=s.next();
		String mobilepattern="[7-9][0-9]{9}";
		
		if(Pattern.matches(mobile,mobilepattern))
		{
			System.out.println("valid mobile No");
		}
		else
		{
			System.out.println("Only 10 didgits & starts with 7 or 8 or 9");
		}
	
	
	}
}
