package com.cg.fms.bean;

	/* Name                                      Null?    Type
 ----------------------------------------- -------- -----------------

 EMPLOYEE_ID                               NOT NULL NUMBER(5)
 EMPLOYEENAME                                       VARCHAR2(50)
 PASSWORD                                           VARCHAR2(20)
 ROLE                                               VARCHAR2(20)
*/
public class EmployeeBean 
{
	private long employeeId;
	private String employeeName;
	private String role;
	private String skillSet;
	
	public EmployeeBean()
	{
		super();
	}

	public EmployeeBean(long employeeId, String employeeName, String role,
			 String skillSet)
	{
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.role = role;
		
		this.skillSet = skillSet;
	}

	public long getEmployeeId()
	{
		return employeeId;
	}

	public void setEmployeeId(long employeeId) 
	{
		this.employeeId = employeeId;
	}

	public String getEmployeeName() 
	{
		return employeeName;
	}

	public void setEmployeeName(String employeeName) 
	{
		this.employeeName = employeeName;
	}

	public String getRole() 
	{
		return role;
	}

	public void setRole(String role) 
	{
		this.role = role;
	}

	public String getSkillSet() 
	{
		return skillSet;
	}

	public void setSkillSet(String skillSet) 
	{
		this.skillSet = skillSet;
	}

	@Override
	public String toString()
	{
		return "EmployeeBean [employeeId=" + employeeId + ", employeeName="
				+ employeeName + ", role=" + role + ", skillSet=" + skillSet + "]";
	}
	
	
	
}
