package com.cg.fms.dao;

import com.cg.fms.bean.*;
import com.cg.fms.exception.FeedbackException;

public interface IFmsDao 
{
	public long getEmployeeId(EmployeeBean ebean)throws FeedbackException;
	public long insertCourseDetails(CourseBean cbean)throws FeedbackException;
	public FeedbackBean getFeedbackByTrainingCode(long trainingCode)throws FeedbackException;
	public FeedbackBean getFeedbackByParticipantId(long participantId)throws FeedbackException;

}
