class Greet
{
public static void main(String args[])	
{ 
String firstName=args[0]; 
int sal  =Integer.parseInt(args[1]);
System.out.println("welcome to java" +firstName+sal);
}
}

class WishMe
{
public static void main(String args[])
{
String name="ABC";     
System.out.println("welcome to java" +name);
}
}