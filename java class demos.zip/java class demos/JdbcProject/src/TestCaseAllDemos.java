import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;


public class TestCaseAllDemos
{

	public static void main(String[] args)
	{
		int choice;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter your choice to perform operation"+"\n"
				+"1.Insering rows into table"+"\t"+"2.updating rows based on employeee salary"+"\t"+"\n"+
				"3.deleting rows based on employee id"+"\t"+"\n"+
				"4.Select rows based on employee id"+"\t"+"5.selecting all rows from table");
		choice=s.nextInt();
		Connection cn=null;
		Statement st=null;
		PreparedStatement pst=null;
		ResultSet rs=null;

		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Capgemini123");

			switch(choice)
			{
			case 1:

				System.out.println("Enter number of employees you want to enter");
				int n=s.nextInt();

				String insertQry="insert into emp_142546(emp_id,emp_name,emp_sal)values(?,?,?)";

				pst=cn.prepareStatement(insertQry);

				for(int i=1;i<=n;i++)
				{

					System.out.println("Enter employee id:");
					int empId=s.nextInt();

					System.out.println("Enter employee name:");
					String empName=s.next();

					System.out.println("Enter employee salary:");
					float empSal=s.nextFloat();


					pst.setInt(1, empId);
					pst.setString(2, empName);
					pst.setFloat(3, empSal);

					int data=pst.executeUpdate();
					System.out.println("Data is added...");
				}

				break;

			case 2:

				st=cn.createStatement();

				String updateQry="Update emp_142546 set emp_sal=emp_sal+10000 where emp_sal>20000";
				int data1=st.executeUpdate(updateQry);

				System.out.println("Data updated"+data1);

				break;

			case 3:

				System.out.println("Enter employee id:");
				int empId=s.nextInt();

				String deleteQry="delete from emp_142546 where emp_id=?";

				pst=cn.prepareStatement(deleteQry);
				pst.setInt(1, empId);

				int data2=pst.executeUpdate();

				System.out.println("Data is deleted from employee table...");

				break;

			case 4:


				System.out.println("Enter employee id:");
				int empId2=s.nextInt();

				String selectQry="select * from emp_142546 where emp_id=?";
				pst=cn.prepareStatement(selectQry);

				pst.setInt(1,empId2);
				rs=pst.executeQuery();
				rs.next();
				System.out.println(rs.getInt("emp_id")+"\t"+rs.getString("emp_name")+"\t"+rs.getString("emp_sal")+"\t"+rs.getDate("emp_doj"));
				System.out.println("selected rows...");
				break;


			case 5:

				st=cn.createStatement();
				rs=st.executeQuery("select * from emp_142546");
				while(rs.next())
				{
					System.out.println("ID \t NAME \t SALARY \t DOJ");
					System.out.println(rs.getInt("emp_id")+"\t"+rs.getString("emp_name")+"\t"+rs.getString("emp_sal")+"\t"+rs.getDate("emp_doj"));	
				}

				break;


			default:

				break;

			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

	}
}