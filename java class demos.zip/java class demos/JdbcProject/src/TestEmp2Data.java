import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Scanner;


public class TestEmp2Data 
{

	public static void main(String[] args)
	{
		Connection cn=null;
		Scanner s=null;
		PreparedStatement pst;
	try
	{
	s=new Scanner(System.in);
	Class.forName("oracle.jdbc.driver.OracleDriver");
	cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Capgemini123");
	
	System.out.println("Enter employee id:");
	int empId=s.nextInt();
	
	System.out.println("Enter employee name:");
	String empName=s.next();
	
	System.out.println("Enter employee salary:");
	float empSal=s.nextFloat();
	
	String insertQry="insert into emp_142546(emp_id,emp_name,emp_sal)values(?,?,?)";
	
	pst=cn.prepareStatement(insertQry);
	pst.setInt(1, empId);
	pst.setString(2, empName);
	pst.setFloat(3, empSal);
	
	int data=pst.executeUpdate();
	System.out.println("Data is added...");
	}
	catch (Exception e)
	{
		e.printStackTrace();
	}
		

	}

}
