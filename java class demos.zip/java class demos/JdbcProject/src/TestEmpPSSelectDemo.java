import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;


public class TestEmpPSSelectDemo 
{

	public static void main(String[] args) 
	{
		Connection cn=null;
		ResultSet rs=null;
		PreparedStatement pst;
		Scanner s=null;
	try
	{
	s=new Scanner(System.in);
	Class.forName("oracle.jdbc.driver.OracleDriver");
	cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Capgemini123");
	
	System.out.println("Enter employee id:");
	int empId=s.nextInt();
	
	String selectQry="select * from emp_142546 where emp_id=?";
	pst=cn.prepareStatement(selectQry);

	pst.setInt(1,empId);
	rs=pst.executeQuery();
	rs.next();
	System.out.println("selected rows...");
	System.out.println(rs.getInt("emp_id")+"\t"+rs.getString("emp_name")+"\t"+rs.getString("emp_sal")+"\t"+rs.getDate("emp_doj"));	
	}
	
	catch (Exception e)
	{
		e.printStackTrace();
	}

	}

}
