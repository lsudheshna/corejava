import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;


public class TestResultSetMetaData
{

	public static void main(String[] args)
	{
		Connection cn=null;
		ResultSet rs=null;
		Statement st=null;
		ResultSetMetaData rsmd=null;

		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Capgemini123");
			st=cn.createStatement();
			rs=st.executeQuery("select * from emp_142546");
			rsmd=rs.getMetaData();
			int columnCount=rsmd.getColumnCount();

			System.out.println("No of columns:"+columnCount);

			for(int i=1;i<=columnCount;i++)
			{
				System.out.println(i+"Column Name: "+rsmd.getColumnName(i));
				System.out.println(i+"Column Type: "+rsmd.getColumnTypeName(i));
				System.out.println(i+"Column Label: "+rsmd.getColumnLabel(i));
				System.out.println("***************");
			}

		}

		catch (Exception e)
		{
			e.printStackTrace();
		}


	}

}
