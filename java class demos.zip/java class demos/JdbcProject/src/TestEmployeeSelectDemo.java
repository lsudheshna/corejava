import java.sql.*;


public class TestEmployeeSelectDemo 
{
	public static void main(String args[])
	{
		//loading oracle driver into memory
		Connection cn=null;
		ResultSet rs=null;
		Statement st=null;
	try
	{
	Class.forName("oracle.jdbc.driver.OracleDriver");
	cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Capgemini123");
	st=cn.createStatement();
	rs=st.executeQuery("select * from emp_142546");
	while(!rs.next()==false)
	{
	System.out.println("ID \t NAME \t SALARY \t DOJ");
	System.out.println(rs.getInt("emp_id")+"\t"+rs.getString("emp_name")+"\t"+rs.getString("emp_sal")+"\t"+rs.getDate("emp_doj"));	
	}
	}
	
	catch (Exception e)
	{
		e.printStackTrace();
	}
		
	
	}
}
