import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class TestEmployeeInsertDemo 
{

	public static void main(String[] args) 
	{
		Connection cn=null;
		Statement st=null;
	try
	{
	Class.forName("oracle.jdbc.driver.OracleDriver");
	cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Capgemini123");
	st=cn.createStatement();
	String insertQry="insert into emp_142546("+"emp_id,emp_name,emp_sal)"+"values(555,'kavitha',9500.0)";
	int data=st.executeUpdate(insertQry);
	//int data=st.executeUpdate("insert into emp_142546 values(555,'kavitha',9500.0)");
	System.out.println("Data inserted into table"+data);
	}
	catch (Exception e)
	{
		e.printStackTrace();
	}
		

	}

}
