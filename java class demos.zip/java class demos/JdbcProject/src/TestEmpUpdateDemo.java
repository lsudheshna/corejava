import java.sql.Connection;
		import java.sql.DriverManager;
		import java.sql.ResultSet;
		import java.sql.Statement;

public class TestEmpUpdateDemo
{

	public static void main(String[] args) 
	{

				Connection cn=null;
				Statement st=null;
			try
			{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Capgemini123");
			st=cn.createStatement();
			
			String updateQry="Update emp_142546 set emp_sal=emp_sal+10000 where emp_sal<20000";
			int data=st.executeUpdate(updateQry);
			
			System.out.println("Data updated");
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			
	}

}
