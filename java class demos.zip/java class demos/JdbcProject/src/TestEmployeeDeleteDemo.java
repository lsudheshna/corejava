import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;


public class TestEmployeeDeleteDemo 
{

	public static void main(String[] args)
	{
		
		Connection cn=null;
		Scanner s=null;
		PreparedStatement pst=null;
	try
	{
		
	s=new Scanner(System.in);
	Class.forName("oracle.jdbc.driver.OracleDriver");
	cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Capgemini123");
	
	System.out.println("Enter employee id:");
	int empId=s.nextInt();
	
	String deleteQry="delete from emp_142546 where emp_id=?";
	
	pst=cn.prepareStatement(deleteQry);
	pst.setInt(1, empId);
	
	int data=pst.executeUpdate();
	
	System.out.println("Data is deleted from employee table...");

	}
	
	
	catch (Exception e)
	{
		e.printStackTrace();
	}
		

	}

}
