import java.util.Scanner;


public class TestDateDemo2
{

	public static void main(String[] args)
	{		
		int dayOfDoj=0;
		int monthOfDoj=0;
		int yearOfDoj=0;
		Date allDojs[]=new Date[3];
		String names[]=new String[3];
		
		
		Scanner s=new Scanner(System.in);
		
			for(int i=0;i<allDojs.length;i++)
			{
				
			System.out.println("Enter Name:");
			names[i]=s.next();
			
			System.out.println("Enter Day:");
			dayOfDoj=s.nextInt();
			
			System.out.println("Enter month of joining:");
			monthOfDoj=s.nextInt();
			
			System.out.println("Enter Year of joining:");
			yearOfDoj=s.nextInt();
			
			allDojs[i]=new Date(dayOfDoj,monthOfDoj,yearOfDoj);
		
				System.out.println("DOJ:"+allDojs[i].dispDate());
				System.out.println("name:"+names[i]);

			}
	
	}


}