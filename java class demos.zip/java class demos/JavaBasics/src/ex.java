
public class ex {
	  public static void main(String args[]) {
		  A a =new A();
	    B b = new B();
	  }
	}
	class A {
	  A() {
	    System.out.print("A");
	  }
	}
	class B extends A{
	  B() {
	    System.out.print("B");
	  }
	}