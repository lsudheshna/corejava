import java.util.Scanner;


public class TestDateDemo {

	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		
		System.out.println("Enter Day:");
		int dayOfDoj=s.nextInt();
		
		System.out.println("Enter month:");
		int monthOfDoj=s.nextInt();
		
		System.out.println("Enter Year:");
		int yearOfDoj=s.nextInt();
		
		Date sudheshnaDOJ= new Date(dayOfDoj,monthOfDoj,yearOfDoj);
		System.out.println("MY DOJ:"+sudheshnaDOJ.dispDate());
		
		System.out.println("Enter Day:");
		int dayOfDoj1=s.nextInt();
		
		System.out.println("Enter month:");
		int monthOfDoj1=s.nextInt();
		
		System.out.println("Enter Year:");
		int yearOfDoj1=s.nextInt();
		Date channaDOJ= new Date(dayOfDoj1,monthOfDoj1,yearOfDoj1);
		System.out.println("OUR DOJ:"+channaDOJ.dispDate());
	}

};
