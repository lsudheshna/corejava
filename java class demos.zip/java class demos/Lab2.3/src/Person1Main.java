
public class Person1Main {

	public static void main(String[] args)
	{
		
				Person1 p1=new Person1();
				Person1 p2=new Person1();
				p1.setPerson1("sudheshna","channa",'F',9987865421l);
				p2.setPerson1("Apoorva","Shetty",'F',8524325161l);
				
				
				System.out.println("Person Details");
				System.out.println("----------------------");
				System.out.println(p1.dispPersonDetails());
				System.out.println();

				System.out.println("Person Details");
				System.out.println("----------------------");
				System.out.println(p2.dispPersonDetails());


	}

}
