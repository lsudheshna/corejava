import static java.lang.Math.*;
class Parent
{
	public void print()
	{
	System.out.println("Parent:");
	}
	public int add(int ... numbers)
	{
		int sum=0;
		for(int j=0;j<numbers.length;j++)
		{
		sum+=numbers[j];
		}
		return sum;
	}
}
class child extends Parent
{
	@Override
	public void print()
	{
	System.out.println("Child:");
	}
}
public class Java5FeaturesDemo1
{
	public static void main(String args[])
	{
		System.out.println("PI="+PI);
		System.out.println("cube of 2="+pow(2,3));
		
		Parent pp=new Parent();
		System.out.println("Addition is:"+pp.add(9,80));
		System.out.println("Addition is:"+pp.add(9,80,10));
		System.out.println("Addition is:"+pp.add(9,80));
		
	//Enhanced for loop
		System.out.println("Enhanced for loop");
		int marks[]=new int[3];
		marks[0]=90;
		marks[1]=80;
		marks[2]=89;
				
				
		String cityList[]={"pune","xxx","yyy","zzz"};
		for(int tempMarks:marks)
		{
			System.out.println(tempMarks);
		}
		for(String city:cityList)
		{
			System.out.println(city);
		}
	}
}
