class Average
{
	public static void main(String args[])	
	{ 
		float sum=0;
		float avg=0;
		int limit=args.length;
		for(int i=0;i<limit;i++)
		{
			sum+=Integer.parseInt(args[i]);
			
			
		}
		avg=sum/limit;
		System.out.println(avg);
		System.out.println(sum);
	}
}