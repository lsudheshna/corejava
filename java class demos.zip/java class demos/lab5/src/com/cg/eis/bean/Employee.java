package com.cg.eis.bean;

import com.cg.eis.service.Service;

public class Employee 
{
		private int empId;
		private String empName;
		private float eSal;
		private String edes;
		Service insurance;
		
		public Employee() 
		{
			super();
			
		}
		
		public int getEmpId() 
		{
			return empId;
		}

		public void setEmpId(int empId) 
		{
			this.empId = empId;
		}

		public String getEmpName() 
		{
			return empName;
		}

		public void setEmpName(String empName) 
		{
			this.empName = empName;
		}

		public float getEmpSal()
		{
			return eSal;
		}

		public void setEmpSal(float eSal)
		{
			this.eSal = eSal;
		}

		public String getDesignation()
		{
			return edes;
		}

		public void setDesignation(String edes)
		{
			this.edes = edes;
		}

	

		public Employee(int empId, String empName, float eSal,
				String edes,Service insurance)
		{
			super();
			this.empId = empId;
			this.empName = empName;
			this.eSal = eSal;
			this.edes = edes;
			this.insurance=insurance;
			
		}
		
	
		public String dispEmployeeInfo()
		{
			return "Employee [empId=" + empId + ", empName=" + empName
					+ ", eSal=" + eSal + ", designation=" + edes + 
					",insurancescheme="+insurance.dispService(eSal,edes)+"]";
		}
	
		
}


