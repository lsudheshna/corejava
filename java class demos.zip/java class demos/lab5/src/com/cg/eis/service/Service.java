package com.cg.eis.service;

public  class Service implements EmployeeService
{
	
	public String dispService(float eSal,String edes)
	{
		
		String Scheme=null;
		if((eSal>5000 && eSal<20000)&&(edes.equals("SYSTEMASSOSCIATE")))
		{
			return "SchemeA";
						//System.out.println("SchemeA");
		}
		else if((eSal>=20000 && eSal<40000)&&(edes.equals("PROGRAMMER")))
		{
			//System.out.println("SchemeB");
			return "SchemeB";
		}
		else if((eSal>=40000)&&(edes.equals("MANAGER")))
		{
			//System.out.println("SchemeC");
			return "SchemeC";	
		}
		else if((eSal<5000)&&(edes.equals("CLERK")))
		{
			//System.out.println("NO SCheme");
			return "NoScheme";
		}
		return  Scheme;
		
		
		
			
	}
	
}
