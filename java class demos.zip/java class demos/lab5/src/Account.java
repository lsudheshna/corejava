
public abstract class Account 
{
	public abstract void withdraw(double amt);
}
