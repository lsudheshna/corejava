package com.cg.mobmgm.bean;

public class PurchaseDetails
{
	private int purchaseId;
	private String customerName;
	private String mailId;
	private long phoneNumber;
	private String purchasedate;
	private int  mobileId;
	

	public PurchaseDetails() 
	{
		super();
		
	}
	
	
	public PurchaseDetails(int purchaseId, String customerName, String mailId,
			long phoneNumber, String purchasedate,int mobileId)
	{
		super();
		this.purchaseId = purchaseId;
		this.customerName = customerName;
		this.mailId = mailId;
		this.phoneNumber = phoneNumber;
		this.purchasedate = purchasedate;
		this.mobileId=mobileId;
	
	}


	public String getCustomerName()
	{
		return customerName;
	}
	public void setCustomerName(String customerName) 
	{
		this.customerName = customerName;
	}
	public String getMailId()
	{
		return mailId;
	}
	public void setMailId(String mailId)
	{
		this.mailId = mailId;
	}
	public long getPhoneNumber() 
	{
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) 
	{
		this.phoneNumber = phoneNumber;
	}
	public int getMobileId()
	{
		return mobileId;
	}
	public void setMobileId(int mobileId)
	{
		this.mobileId = mobileId;
	}
	public int getPurchaseId()
	{
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId)
	{
		this.purchaseId = purchaseId;
	}
	public String getPurchasedate()
	{
		return purchasedate;
	}
	public void setPurchasedate(String purchasedate) 
	{
		this.purchasedate = purchasedate;
	}


	
	public String dispPurchaseDetails() 
	{
		return "PurchaseDetails [purchaseId=" + purchaseId + ", customerName="
				+ customerName + ", mailId=" + mailId + ", phoneNumber="
				+ phoneNumber + ", purchasedate=" + purchasedate
				+ ", mobileId=" + mobileId+"]";
	}
	
}
