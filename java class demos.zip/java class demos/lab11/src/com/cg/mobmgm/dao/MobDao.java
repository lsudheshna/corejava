package com.cg.mobmgm.dao;

import java.util.ArrayList;

import com.cg.mobmgm.bean.Mobile;
import com.cg.mobmgm.bean.PurchaseDetails;
import com.cg.mobmgm.exception.MobileException;

public interface MobDao
{
	public int addMobile(PurchaseDetails pd)throws MobileException;
	public ArrayList<Mobile> getAllMobiles() throws MobileException;
	public int generatePurchaseId() throws MobileException;
	public int updateMobileQuantity(int mobileId)throws MobileException;
	public int deleteMobile(int mobileId)throws MobileException;
	public ArrayList<Integer> getMobileId() throws MobileException;
	public ArrayList<Mobile> searchMobiles(float minprice, float maxprice)
			throws MobileException;
}
