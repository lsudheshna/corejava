package com.cg.mobmgm.service;

import java.util.ArrayList;

import com.cg.mobmgm.bean.Mobile;
import com.cg.mobmgm.bean.PurchaseDetails;
import com.cg.mobmgm.exception.MobileException;

public interface MobService
{
	public int addMobile(PurchaseDetails pd)throws MobileException;
	public ArrayList<Mobile> getAllMobiles() throws MobileException;
	public int generatePurchaseId() throws MobileException;
	public int updateMobileQuantity(int mobileId)throws MobileException;
	public int deleteMobile(int mobileId)throws MobileException;
	public ArrayList<Mobile> searchMobiles(float minprice,float maxprice) throws MobileException;
	public ArrayList<Integer> getMobileId() throws MobileException;
	/*public int getMobileQuantity(Mobile mob) throws MobileException;*/
	
	
	
	public boolean validateMobileId(int mobileId)throws MobileException;
	public boolean validateCustName(String customerName)throws MobileException;
	public boolean validatemailId(String mailId)throws MobileException;
	public boolean validatephnNumber(long phoneNumber)throws MobileException;
	//public boolean validateQuantity(PurchaseDetails pd)throws MobileException;

}

