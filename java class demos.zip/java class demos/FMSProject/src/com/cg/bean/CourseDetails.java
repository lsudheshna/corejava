package com.cg.bean;

public class CourseDetails 
{
	private long courseId;
	private String courseName;
	private int duration;
}
