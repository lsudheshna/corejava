import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;


public class TestDeserializationDemo
{

	public static void main(String[] args)
	{
		Emp emp=null;
		FileInputStream fis;
		try
		{
			fis = new FileInputStream("EmpData.obj");
			ObjectInputStream ois = new ObjectInputStream(fis);
			emp=(Emp)ois.readObject();
			System.out.println(emp);
			System.out.println("emp object is written in a file");
		}
		catch(IOException e)
		{
			e.printStackTrace();
		} catch (ClassNotFoundException e)
		{
			
			e.printStackTrace();
		}
		
	}

}
