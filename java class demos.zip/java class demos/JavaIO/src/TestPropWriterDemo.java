import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;


public class TestPropWriterDemo {

	public static void main(String[] args)
	{
		FileWriter fw=null;
		Properties pw=null;
		try 
		{
			fw=new FileWriter("dbInfo.properties");
			pw=new Properties();
			pw.setProperty("dbUrl","jdbc:oracle:thin");
			pw.setProperty("dbUserName","system");
			pw.setProperty("dbPwd","root");
			pw.store(fw, "This is Orcale DB Credentials");
			System.out.println("Data written in properties file");
		} 
		catch (IOException e)
		{
			
			e.printStackTrace();
		}

	}

}
