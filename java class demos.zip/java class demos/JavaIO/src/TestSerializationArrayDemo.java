import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;


public class TestSerializationArrayDemo
{

	public static void main(String[] args)
	{
		Emp emps[]=new Emp[3];
		FileOutputStream fos = null;
		ObjectOutputStream oos = null;
		try 
		{
			fos = new FileOutputStream("EmpData.obj");
			 oos = new ObjectOutputStream(fos);
		} 
		catch (Exception e1) 
		{
			
			e1.printStackTrace();
		}
		
	try
	{
		for(int i=0;i<emps.length;i++)
		{
		Scanner s=new Scanner(System.in);
		
		System.out.println("Enter emp id");
		int empId=s.nextInt();
		
		System.out.println("Enter emp Name");
		String empName=s.next();
		
		System.out.println("Enter emp salary");
		float empsal=s.nextFloat();
		emps[i]=new Emp(empId,empName,empsal);
		oos.writeObject(emps[i]);
		System.out.println("emp object is written in a file");
		}
	}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		}
	}


