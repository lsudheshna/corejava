import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;


public class TestPropertyFileDemo {

	public static void main(String[] args) 
	{
		FileReader fr=null;
		Properties props=null;
		try 
		{
			fr=new FileReader("userInfo.properties");
			props=new Properties();
			props.load(fr);
			System.out.println("***all data****");
			
				String unm=props.getProperty("username");
				System.out.println("USER NAME:"+unm);

				String pwd=props.getProperty("password");
				System.out.println("PASSWORD:"+pwd);
						
				String location=props.getProperty("location");
				System.out.println("LOCATION:"+location);
				
				String state=props.getProperty("state");
				System.out.println("STATE:"+state);
				
				System.out.println("USER NAME:"+unm+" "+"PASSWORD:"+pwd+" "+"LOCATION:"+location+" "+"STATE:"+state);
		} 
		catch (IOException e)
		{
			
			e.printStackTrace();
		}
		

	}

}
