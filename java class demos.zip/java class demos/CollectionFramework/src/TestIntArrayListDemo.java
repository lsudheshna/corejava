import java.util.*;

//ArrayList is dynamic and is generic so we r preferring this than arrays...so we go for APIs
public class TestIntArrayListDemo 
{
	public static void main(String args[])
	{
		//making arraylist generic so that it is type safe & allows only integer values
		ArrayList<Integer>intList=new ArrayList<Integer>();
		
		Integer i1=new Integer(10);//dealing with objects (creating primitive to objects)
		Integer i2=new Integer(20);
		Integer i3=new Integer(30);
		Integer i4=new Integer(40);
		Integer i5=new Integer(40);
		
		intList.add(i1);//adding objects into arraylist
		intList.add(i2);
		intList.add(i3);
		intList.add(i4);
		intList.add(i5);
		
		System.out.println(intList);//without iterator
		
		//iterator points to null or first entry
		
		Iterator<Integer> it=intList.iterator();//iterator is provided for retrieving object one by one
		
		while(it.hasNext())//going for next obj till the last one
		{
			System.out.println(":"+it.next());//fetching next object
			//int tempNum=it.next();
			//System.out.println(":"+tempNum);
		}
	}
}
