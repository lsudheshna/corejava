import java.util.HashSet;


public class TestEmpHashSetDemo
{

	public static void main(String[] args)
	{
	
		
		
		
		
		
			HashSet<Emp> empSet=new HashSet<Emp>();
								
			Emp e1=new Emp(333,"sudheshna",4000.00f);
			Emp e2=new Emp(222,"sudheshna1",4300.00f);
			Emp e3=new Emp(311,"sudheshna2",4540.00f);
			Emp e4=new Emp(323,"sudheshna3",4400.00f);
			Emp e5=new Emp(113,"sudheshna4",4500.00f);
			Emp e6=new Emp(333,"sudheshna",4000.00f);
			
			empSet.add(e1);
			empSet.add(e2);
			empSet.add(e3);
			empSet.add(e4);
			empSet.add(e5);
			empSet.add(e6);
			
			for(Emp temp:empSet)
			{
				System.out.println(temp);
			}
			

	}

}
