import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;


public class TestHashMapDemo 
{

	public static void main(String[] args)
	{
		HashMap<Long,String> mobileDirectory=new HashMap<Long,String>();
		
		 mobileDirectory.put(8881117772l,"xxx");
		 mobileDirectory.put(9881117772l,"xyz");
		 mobileDirectory.put(9782317772l,"yyy");
		 mobileDirectory.put(9821457672l,"ppp");
		 mobileDirectory.put(8186371372l,"zzz");
		 
		 //every entry in map goes to set ,so that corresponding subset(key,value) in set can be retrieved
		 Set<Entry<Long,String>> setIt=mobileDirectory.entrySet();
		 //Iterator has an entry and subset goes to Iterator
		 Iterator<Entry<Long,String>> mobIt= setIt.iterator();
		 
		 while(mobIt.hasNext())
		 {
			 Entry<Long,String> dirEntry=mobIt.next();
			 System.out.println("Mobile:"+dirEntry.getKey()+"Name:"+dirEntry.getValue());
		 //getkey() and getvalues() are used to retrieve keys and values 
		 }
		 
	}

}
