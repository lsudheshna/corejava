import java.util.HashSet;
import java.util.TreeSet;


public class TestIntTreeSetDemo 
{

	public static void main(String[] args)
	{
		TreeSet<Integer>treeSet=new TreeSet<Integer>();
		
		Integer i1=new Integer(10);//dealing with objects (creating primitive to objects)
		Integer i2=new Integer(20);
		Integer i3=new Integer(30);
		Integer i4=new Integer(40);
		Integer i5=new Integer(40);
							
		treeSet.add(i1);//adding objects into arraylist
		treeSet.add(i2);
		treeSet.add(i3);
		treeSet.add(i4);
		treeSet.add(i5);
							
		System.out.println(treeSet);
									

	}

}
