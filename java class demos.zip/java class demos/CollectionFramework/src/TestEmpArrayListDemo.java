import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class TestEmpArrayListDemo 
{
	public static void main(String[] args)
	{
		ArrayList<String> empList= new ArrayList<>();
		
		Emp e1=new Emp(333,"sudheshna",4000.00f);
		Emp e2=new Emp(222,"sudheshna1",4300.00f);
		Emp e3=new Emp(311,"sudheshna2",4540.00f);
		Emp e4=new Emp(113,"sudheshna3",4500.00f);
		Emp e5=new Emp(113,"sudheshna3",4500.00f);
		empList.add("e5");
		empList.add("e1");
		empList.add("e2");
		empList.add("e3");
		empList.add("e5");
		
		empList.remove("e5");
		System.out.println(empList);
		
		
		/*ArrayList<Integer> list = new ArrayList<>(1);
		list.add(1001);
		list.add(1002);
		System.out.println(list.get(list.size()));*/
		
		/*ArrayList<Integer> list = new ArrayList<>(1);
		list.add(1001);
		list.add(1002);
		System.out.println(list.get(list.size()));*/
		
		 Set s = new TreeSet();
		 s.add("7");
		 s.add(9);
		 Iterator itr = s.iterator();
		 while (itr.hasNext())
		 System.out.print(itr.next() + " ");
	
	
		/*Iterator<Emp> it=empList.iterator();
		/*while(it.hasNext())
		{
			System.out.println(":"+it.next());
		}
		while(it.hasNext())
		{
			Emp tempEmp=it.next();
			System.out.println("Id:"+tempEmp.getEmpId());
			System.out.println("Name:"+tempEmp.getEmpName());
			System.out.println("Salary:"+tempEmp.getEmpSal());*/
			
		}
	}


