import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;


public class TestHashSetDemo 
{

	public static void main(String[] args) 
	{
			
		HashSet<Integer>intSet=new HashSet<Integer>();
							
		Integer i1=new Integer(10);//dealing with objects (creating primitive to objects)
		Integer i2=new Integer(20);
		Integer i3=new Integer(30);
		Integer i4=new Integer(40);
		Integer i5=new Integer(40);
							
		intSet.add(i1);//adding objects into arraylist
		intSet.add(i2);
		intSet.add(i3);
		intSet.add(i4);
		intSet.add(i5);
							
		System.out.println(intSet);
										
	
	}

}
