import java.util.HashSet;
import java.util.TreeSet;


public class TestEmpTreeSetDemo
{

	public static void main(String[] args) 
	{
		TreeSet<Emp> treeSet=new TreeSet<Emp>();
		
		Emp e1=new Emp(333,"sudheshna",4000.00f);
		Emp e2=new Emp(222,"sudheshna1",4300.00f);
		Emp e3=new Emp(311,"sudheshna2",4540.00f);
		Emp e4=new Emp(323,"sudheshna3",4400.00f);
		Emp e5=new Emp(113,"sudheshna4",4500.00f);
		Emp e6=new Emp(333,"sudheshna",4000.00f);
		
		treeSet.add(e1);
		treeSet.add(e2);
		treeSet.add(e3);
		treeSet.add(e4);
		treeSet.add(e5);
		treeSet.add(e6);
		
		for(Emp temp:treeSet)
		{
			System.out.println(temp);
		}
	}

}
