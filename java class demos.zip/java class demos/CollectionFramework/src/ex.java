
		import java.util.HashMap;
		import java.util.Iterator;
		import java.util.Map.Entry;
		import java.util.Set;

public class ex {

	public static void main(String[] args)
	{
		
		{
				HashMap<Long,String> mobileDirectory=new HashMap<Long,String>();
				
				 mobileDirectory.put(8881117772l,"xxx");
				 mobileDirectory.put(9881117772l,"xyz");
				 mobileDirectory.put(9782317772l,"yyy");
				 mobileDirectory.put(9821457672l,"ppp");
				 mobileDirectory.put(8186371372l,"zzz");
				 
				 //every entry in map goes to set ,so that corresponding subset(key,value) in set can be retrieved
				 Set<Long> setIt=mobileDirectory.keySet();
				
				 Iterator<Long> mobIt= setIt.iterator();
				 
				 while(mobIt.hasNext())
				 {
					
					 System.out.println("Mobile:"+ mobIt.next());
				 
				 }
				 
			}

		}

	}


